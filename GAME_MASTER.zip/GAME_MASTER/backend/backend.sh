#!/bin/bash
java -jar backend.jar
