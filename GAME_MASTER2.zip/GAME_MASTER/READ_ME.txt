--TO-RUN----------------
Open 2 Terminals Windows
--REQUIRED-DOWNLOADS(IF NOT ALREADY INSTALLED)-----
Java version 17 - sudo apt install openjdk-17-jdk
Netcat - sudo apt install netcat-openbsd

Go to GAME_MASTER/backend
--1ST-TERMINAL-----------
Run backend.sh
Should Boot up Springboot
--2ND-TERMINAL-----------
Type in "nc -l -u 127.0.0.1 7500"
--PROGRAM----------------
Go to GAME_MASTER/MAIN_FILES/MAIN
Launch "index.html"
--FUNCTIONALITIES--------
All are buttons btw, keys are not implemented
Insert Players:
Pushes all filled in ID and CODENAMES into Database, and prints them on 1st Terminal Window
New Address:
Replaces the default Address 127.0.0.1 with whatever valid address you want, and prints current(new) address on 1st Terminal Window
Clear Players:
Clears all current players on the board from it and deletes them from the Database, also prints the database afterwards
--IMPORTANT-------------
If you decide to stop SpringBoot, the program on your first window, make sure to kill it after closing the program. Run these commands:
ps aux | grep '[j]ava.*backend-0.0.1-SNAPSHOT.jar'
To see the PID, should be first line that pops up, first num
EX:
ferna     12345  2.3  1.2 500000 20000 ?  Sl   15:30   0:10 java -jar backend.jar
ferna     12346  0.0  0.0  21584  1060 pts/0 S+   15:45   0:00 grep --color=auto java

PID is 12345

Then run:
kill -9 PID //PID is your, well PID

Then Run program again for further testing, if found wanting